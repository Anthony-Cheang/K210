#include <fpioa.h>
#include <gpio.h>
#include <sleep.h>

int main(void) {
  gpio_init(); //初始化io
  fpioa_set_function(12, FUNC_GPIO1); //把io1映射到k210 12引脚
  gpio_set_drive_mode(1, GPIO_DM_OUTPUT);//把io1设置为输出
  gpio_set_pin(1, 1);//io1置高电平
  while (1) {
    gpio_set_pin(1, 0);//io1置高电平 点灯
    msleep(500);
    gpio_set_pin(1, 1);//io1置低电平 灭灯
    msleep(500);
  }
}
